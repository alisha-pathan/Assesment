import React, { useState } from 'react'

function Accorparent() {

  const [current, setcurrent] = useState(false)
  return (
    <>
      <Accorchild title="Panel" open={current == 0} show={() => { setcurrent(0) }} >
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique error, reprehenderit dolor ipsa eveniet reiciendis nesciunt minus nulla, tempore sequi a molestias numquam suscipit ducimus animi sit magni accusantium rerum.
      </Accorchild >
      <hr />
      <Accorchild title="Panel" open={current == 1} show={() => { setcurrent(1) }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique error, reprehenderit dolor ipsa eveniet reiciendis nesciunt minus nulla, tempore sequi a molestias numquam suscipit ducimus animi sit magni accusantium rerum.
      </Accorchild>
      <Accorchild title="Panel" open={current == 2} show={() => { setcurrent(2) }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique error, reprehenderit dolor ipsa eveniet reiciendis nesciunt minus nulla, tempore sequi a molestias numquam suscipit ducimus animi sit magni accusantium rerum.
      </Accorchild>
    </>
  )
}
export default Accorparent



function Accorchild({ children, title, open, show }) {

 const panelStyle = {
    overflow: 'hidden',
    transition: 'max-height 3s ease, padding 0.3s ease',
    background: '#f0f0f0',
    borderRadius: '5px',
    maxHeight: open ? '500px' : '0',
    padding: open ? '10px' : '0 10px',
  };

  return (
    <div style={{ marginBottom: '10px' }}>
      <p>{title}</p>
      {
        open ? <p style={panelStyle}>{children} </p> : <button onClick={show}>▽</button>
      }
    </div>
  )
}

