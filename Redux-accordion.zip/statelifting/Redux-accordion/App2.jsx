import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getindex } from './reducer'

const obj = [
    {
        title: "panel 1",
        content: ' Lorem ipsum dolor sit amet consectetur, adipisicing elit. Vero possimus eos provident! A labore quaerat inventore fugiat fuga deleniti aspernatur consectetur quis consequuntur eum est dignissimos facere, incidunt deserunt doloribus libero voluptatibus! Fugit quo illo consectetur accusantium animi quam libero nostrum quasi consequatur. Blanditiis accusamus deleniti expedita quae praesentium debitis?'
    },
    {
        title: "panel 1",
        content: ' Lorem ipsum dolor sit amet consectetur, adipisicing elit. Vero possimus eos provident! A labore quaerat inventore fugiat fuga deleniti aspernatur consectetur quis consequuntur eum est dignissimos facere, incidunt deserunt doloribus libero voluptatibus! Fugit quo illo consectetur accusantium animi quam libero nostrum quasi consequatur. Blanditiis accusamus deleniti expedita quae praesentium debitis?'
    },
    {
        title: "panel 1",
        content: ' Lorem ipsum dolor sit amet consectetur, adipisicing elit. Vero possimus eos provident! A labore quaerat inventore fugiat fuga deleniti aspernatur consectetur quis consequuntur eum est dignissimos facere, incidunt deserunt doloribus libero voluptatibus! Fugit quo illo consectetur accusantium animi quam libero nostrum quasi consequatur. Blanditiis accusamus deleniti expedita quae praesentium debitis?'
    }
]

function App2() {
    const data = useSelector(state => state.user)
    const dispatch = useDispatch()

    // console.log(data);

    return (
        <>
            {
                obj.map((val, i) => (
                    <Panel
                        key={i}
                        title={val.title}
                        content={val.content}
                        open={data == i}
                        onClick={() => { dispatch(getindex(i)) }}
                    >

                    </Panel>
                ))
            }
        </>
    )
}

export default App2



function Panel({ children, open, onClick, title, content }) {

    const panelStyle = {
        overflow: 'hidden',
        transition: 'max-height 0.5s ease, padding 0.3s ease',
        background: '#f0f0f0',
        borderRadius: '5px',
        maxHeight: open ? '200px' : '0',
        padding: open ? '10px' : '0 10px',
    };

    return (
        <div style={{ marginBottom: '10px' }}>
            <div
                onClick={onClick}
                style={{
                    fontWeight: 'bold',
                    cursor: 'pointer',
                    background: '#ccc',
                    padding: '10px',
                    borderRadius: '5px',
                }}
            >
                {title}
            </div>
            <div style={panelStyle}>
                <p>{content}</p>
            </div>
        </div>
    )
}

