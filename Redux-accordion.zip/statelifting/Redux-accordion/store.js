import { configureStore } from "@reduxjs/toolkit";
import userslice from '../Redux-accordion/reducer';

const store = configureStore({
  reducer: {
    user: userslice,
  },
});

export default store;
