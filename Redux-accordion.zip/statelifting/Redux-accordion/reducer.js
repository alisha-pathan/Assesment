import { createSlice } from "@reduxjs/toolkit";

const userslice = createSlice({
    name: 'accordion',
    initialState: null,
    reducers: {
        getindex: (state, action) => {
            return action.payload
        }
    }
});

export const { getindex } = userslice.actions
export default userslice.reducer;

