import React, { useState } from 'react'

export default function App1() {
    const [active, setactive] = useState(0)
    return (
        <>
            <h1>accordion is here</h1>
            <App1Child title="part 1">
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Porro dignissimos laudantium at eligendi voluptate aperiam! Alias, eaque natus molestiae quo id unde dolorum aliquam praesentium error minus ex quaerat in libero est voluptatibus porro, assumenda deserunt doloribus accusantium tempore maiores aspernatur distinctio beatae? Aperiam iste repudiandae ipsam, sapiente doloribus obcaecati.
            </App1Child>
            <App1Child title="part 2">
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Porro dignissimos laudantium at eligendi voluptate aperiam! Alias, eaque natus molestiae quo id unde dolorum aliquam praesentium error minus ex quaerat in libero est voluptatibus porro, assumenda deserunt doloribus accusantium tempore maiores aspernatur distinctio beatae? Aperiam iste repudiandae ipsam, sapiente doloribus obcaecati.
            </App1Child>
        </>
    )
}

function App1Child({ title, children }) {
    const [isactive, setisactive] = useState(false)

    return (
        <>
            <section className='appchild'>
                <h3>{title}</h3>
                {isactive ?
                    (<p>{children}</p>)
                    : 
                    (
                        <button onClick={()=>setisactive(true)}>show</button>
                    )
            }
            </section>
        </>
    )
}




